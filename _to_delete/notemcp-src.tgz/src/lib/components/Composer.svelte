<script lang="ts">
	import { invalidateAll } from '$app/navigation';
	import { queueNote, syncEntry } from '$lib/outbox';
	import { normalizeTagName, tagClass } from '$lib/tags';
	import type { Tag } from '$lib/types';

	let {
		recentTags = [],
		contextTag = null
	}: { recentTags?: Tag[]; contextTag?: string | null } = $props();

	let open = $state(false);
	let text = $state('');
	let selected = $state<string[]>([]);
	let textarea = $state<HTMLTextAreaElement | null>(null);

	let recording = $state(false);
	let seconds = $state(0);
	let interim = $state('');
	let voiceError = $state('');

	let hasText = $derived(text.trim().length > 0);

	let suggestions = $derived.by(() => {
		const names = recentTags.map((t) => t.name);
		for (const name of selected) if (!names.includes(name)) names.push(name);
		return names.slice(0, 8);
	});

	function openSheet() {
		selected = contextTag ? [contextTag] : [];
		voiceError = '';
		open = true;
		// Autofocus immediately: the sheet exists to catch a thought that is
		// already half-gone, so the caret has to be there before the animation
		// finishes, not after.
		queueMicrotask(() => textarea?.focus());
	}

	function closeSheet() {
		open = false;
		interim = '';
	}

	/** Every exit keeps the text. Discarding is an explicit, separate action. */
	function dismiss() {
		if (hasText) save();
		else closeSheet();
	}

	function discard() {
		text = '';
		closeSheet();
	}

	function toggleTag(name: string) {
		selected = selected.includes(name)
			? selected.filter((t) => t !== name)
			: [...selected, name];
		textarea?.focus();
	}

	function save() {
		const content = text.trim();
		if (!content) return;

		const entry = queueNote({
			title: '',
			content_markdown: content,
			source_url: null,
			source_type: null,
			source_title: null,
			source_description: null,
			source_image: null,
			tagNames: selected.map(normalizeTagName).filter(Boolean)
		});

		text = '';
		closeSheet();
		syncEntry(entry, () => invalidateAll());
	}

	/* ---------------- voice ---------------- */

	type SpeechCtor = new () => any;

	function speechCtor(): SpeechCtor | null {
		if (typeof window === 'undefined') return null;
		return (
			(window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition ?? null
		);
	}

	let recognition: any = null;
	let timer: ReturnType<typeof setInterval> | null = null;

	function startRecording() {
		const Ctor = speechCtor();
		if (!Ctor) {
			// No on-device recognition here — fall back to the keyboard rather
			// than pretending to record something we can't turn into a thought.
			voiceError = 'Voice capture needs Chrome or Safari on this device.';
			openSheet();
			return;
		}

		selected = contextTag ? [contextTag] : [];
		interim = '';
		seconds = 0;
		recording = true;
		timer = setInterval(() => seconds++, 1000);

		recognition = new Ctor();
		recognition.continuous = true;
		recognition.interimResults = true;
		recognition.lang = navigator.language || 'en-US';

		let settled = '';
		recognition.onresult = (event: any) => {
			let pending = '';
			for (let i = event.resultIndex; i < event.results.length; i++) {
				const result = event.results[i];
				if (result.isFinal) settled += result[0].transcript;
				else pending += result[0].transcript;
			}
			interim = (settled + pending).trim();
		};
		recognition.onerror = () => stopRecording(true);
		recognition.onend = () => {
			if (recording) stopRecording();
		};

		try {
			recognition.start();
		} catch {
			stopRecording(true);
		}
	}

	function stopRecording(cancelled = false) {
		recording = false;
		if (timer) clearInterval(timer);
		timer = null;
		try {
			recognition?.stop();
		} catch {
			/* already stopped */
		}
		recognition = null;

		const captured = interim.trim();
		interim = '';
		if (cancelled || !captured) return;

		text = captured;
		save();
	}

	function cancelRecording() {
		interim = '';
		stopRecording(true);
	}

	function onKeydown(event: KeyboardEvent) {
		if (event.key === 'Enter' && !event.shiftKey) {
			event.preventDefault();
			save();
		}
		if (event.key === 'Escape') {
			event.preventDefault();
			dismiss();
		}
	}

	let clock = $derived(`${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`);
</script>

<!-- ---------------- collapsed bar ---------------- -->
<div
	class="safe-bottom pointer-events-none fixed inset-x-0 bottom-0 z-20 flex items-center gap-2 px-[18px] pt-10 pb-5"
	style="background: linear-gradient(180deg, transparent 0%, color-mix(in srgb, var(--color-bg) 90%, transparent) 42%, var(--color-bg) 68%);"
	class:opacity-0={open || recording}
>
	<div
		class="pointer-events-auto flex h-12 flex-1 cursor-text items-center rounded-[0.88rem] pr-1.5 pl-4"
		style="background: var(--color-surface); border: 1px solid var(--color-border); box-shadow: 0 3px 12px rgba(0,0,0,.055);"
		onclick={openSheet}
		onkeydown={(e) => e.key === 'Enter' && openSheet()}
		role="button"
		tabindex="0"
	>
		<span class="flex-1 text-[0.94rem]" style="color: var(--color-ink-faint);">
			{contextTag ? `Write in #${contextTag}…` : 'Write something…'}
		</span>
		<button
			type="button"
			aria-label="Record a thought"
			class="grid h-9 w-9 shrink-0 place-items-center rounded-[0.62rem] active:scale-95"
			style="background: var(--color-accent); color: var(--color-accent-ink);"
			onclick={(e) => {
				e.stopPropagation();
				startRecording();
			}}
		>
			<svg
				width="17"
				height="17"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				><rect x="9" y="3" width="6" height="11" rx="3" /><path
					d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"
				/></svg
			>
		</button>
	</div>

	<a
		href="/search"
		aria-label="Search"
		class="pointer-events-auto grid h-12 w-12 shrink-0 place-items-center rounded-[0.88rem]"
		style="background: var(--color-surface); border: 1px solid var(--color-border); box-shadow: 0 3px 12px rgba(0,0,0,.055); color: var(--color-ink-2);"
	>
		<svg
			width="19"
			height="19"
			viewBox="0 0 24 24"
			fill="none"
			stroke="currentColor"
			stroke-width="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg
		>
	</a>
</div>

<!-- ---------------- recording ---------------- -->
{#if recording}
	<div
		class="safe-bottom fixed inset-x-[18px] bottom-5 z-30 flex items-center gap-3 rounded-[0.88rem] px-4 py-3"
		style="background: var(--color-accent); color: var(--color-accent-ink);"
	>
		<span class="h-2.5 w-2.5 shrink-0 animate-pulse rounded-full" style="background: #ff7b7b;"
		></span>
		<span class="shrink-0 text-[0.85rem] font-medium tabular-nums">{clock}</span>
		<span class="min-w-0 flex-1 truncate text-[0.85rem] opacity-80">{interim || 'Listening…'}</span>
		<button
			type="button"
			class="shrink-0 rounded-[0.56rem] px-3 py-1.5 text-[0.8rem] font-semibold"
			style="background: rgba(255,255,255,.18);"
			onclick={() => stopRecording()}>Keep</button
		>
		<button
			type="button"
			aria-label="Cancel"
			class="shrink-0 px-1 text-[0.9rem] opacity-60"
			onclick={cancelRecording}>✕</button
		>
	</div>
{/if}

<!-- ---------------- sheet ---------------- -->
{#if open}
	<div
		class="fixed inset-0 z-30"
		style="background: rgba(14,14,10,.38);"
		onclick={dismiss}
		onkeydown={(e) => e.key === 'Escape' && dismiss()}
		role="button"
		tabindex="-1"
		aria-label="Close composer"
	></div>

	<div
		class="safe-bottom fixed inset-x-0 bottom-0 z-40 rounded-t-[1.25rem] px-[18px] pt-2.5 pb-4"
		style="background: var(--color-surface); box-shadow: 0 -8px 34px rgba(0,0,0,.16);"
	>
		<div class="mx-auto mb-3 h-1 w-9 rounded-full" style="background: var(--color-border);"></div>

		{#if voiceError}
			<p class="mb-2 text-[0.78rem]" style="color: var(--color-ink-muted);">{voiceError}</p>
		{/if}

		<textarea
			bind:this={textarea}
			bind:value={text}
			onkeydown={onKeydown}
			rows="3"
			placeholder="Write something…"
			class="min-h-[88px] w-full resize-none bg-transparent text-[1.06rem] leading-[1.44] tracking-[-0.017em] outline-none"
		></textarea>

		<!-- Tags sit below the text, not above it: nothing should stand between
		     opening the sheet and writing the sentence. -->
		{#if suggestions.length > 0}
			<div class="mt-3 flex flex-wrap items-center gap-1.5">
				<span class="mr-0.5 text-[0.69rem]" style="color: var(--color-ink-faint);">Recent</span>
				{#each suggestions as name (name)}
					{@const on = selected.includes(name)}
					<button
						type="button"
						class="min-h-7 rounded-[var(--radius-sm)] px-2.5 py-1 text-[0.78rem] font-medium active:scale-95"
						class:border={!on}
						style={on
							? ''
							: 'border-color: var(--color-border); color: var(--color-ink-muted); background: var(--color-surface);'}
						aria-pressed={on}
						onclick={() => toggleTag(name)}
					>
						{#if on}
							<span class={tagClass(recentTags.find((t) => t.name === name)?.color)}>
								#{name}<span class="ml-1 opacity-50">✕</span>
							</span>
						{:else}
							#{name}
						{/if}
					</button>
				{/each}
			</div>
		{/if}

		<div
			class="mt-3 flex items-center gap-2 border-t pt-3"
			style="border-color: var(--color-border);"
		>
			{#if hasText}
				<button
					type="button"
					aria-label="Discard"
					class="grid h-[34px] w-[34px] place-items-center rounded-[0.56rem]"
					style="background: var(--color-danger-soft); color: var(--color-danger);"
					onclick={discard}
				>
					<svg
						width="15"
						height="15"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="1.9"
						stroke-linecap="round"
						stroke-linejoin="round"
						><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" /></svg
					>
				</button>
			{/if}

			<span class="flex-1"></span>

			{#if hasText}
				<span class="text-[0.69rem]" style="color: var(--color-ink-faint);">closes &amp; keeps</span>
			{/if}

			<button
				type="button"
				aria-label={hasText ? 'Keep' : 'Record'}
				class="grid h-11 w-11 place-items-center rounded-[0.8rem] active:scale-95"
				style="background: var(--color-accent); color: var(--color-accent-ink);"
				onclick={() => (hasText ? save() : (closeSheet(), startRecording()))}
			>
				{#if hasText}
					<svg
						width="19"
						height="19"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="2.4"
						stroke-linecap="round"
						stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5" /></svg
					>
				{:else}
					<svg
						width="19"
						height="19"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						stroke-width="2"
						stroke-linecap="round"
						><rect x="9" y="3" width="6" height="11" rx="3" /><path
							d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"
						/></svg
					>
				{/if}
			</button>
		</div>
	</div>
{/if}
